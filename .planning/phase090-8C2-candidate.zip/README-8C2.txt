Task 090-8C.2: additive offline hardening design and synthetic Linux transaction fixtures.
Place three files only under assets/090 and tests, after SHA verification and destination-absence checks.
NO production changes. NO WSL installation. NO --apply. Do not execute the prototype against real paths.
Execute verify-090-linux-transaction.sh only in an ordinary Linux test environment with bash, coreutils and mktemp.
