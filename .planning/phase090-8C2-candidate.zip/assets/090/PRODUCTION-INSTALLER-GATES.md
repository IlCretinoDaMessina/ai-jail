# Phase 090 — 8C.2 production installer hardening specification (candidate)

Status: **OFFLINE DESIGN AND SYNTHETIC TEST ONLY**. This file confers no permission to install, download, modify production scripts, alter WSL or enable `--apply`.

## Gates before generating an executable production installer

1. OpenCode release provenance and downloaded archive/binary hashes reviewed independently; version and source are pinned. Treat a SHA alone as an integrity check, not publisher authentication.
2. GSD Core maintained package version and full transitive dependency lockfile reviewed; exact resolved integrity values, install scripts, optional/platform dependencies, generated configuration and tree hashes examined. Do not run unreviewed package lifecycle scripts.
3. Enumerate installation hostnames plus observed CDN redirects. Keep installation network policy distinct from the runtime provider host policy; neither list silently broadens the other.
4. Confirm which filesystem actor can write source, staging, journal, versioned target and launcher; reject symlink and path substitution at each trust boundary. A shell `test -L` check is not atomic: a production design must control parent-directory write permissions, use safe file operations and defend against time-of-check/time-of-use replacement.
5. Use private root-owned staging on the same filesystem as promotion; check hash and type before and after extraction, reject archive traversal, links, devices, hardlinks and unexpected members. Never execute a staged binary before verification.
6. Record transaction intent and durable state; define interruption windows, fsync/durability, idempotent recovery, and a separate approval for destructive cleanup. Do not overwrite an occupied version or silently repair an ambiguous committed state.
7. Promotion uses immutable version directories and a controlled pointer/launcher update, with prior known-good retained for explicit rollback. Do not treat a single `mv` or this prototype as sufficient for a complete atomic multi-file transaction.
8. Generate OpenCode configuration from reviewed managed sources; independently test precedence against project, user, plugin and environment overrides. Do not store credentials in a generated config.
9. Review localhost exception, authenticated loopback server, permitted runtime provider hosts, no direct external TCP/DNS, denied LAN/host/cross-project access and absence of unwanted namespace-local services. Preserve Phase 080 baselines.
10. All blocking manifest approval fields stay false until separate, recorded user authorisation; no real `--apply`, runtime wrapper replacement, config.env edit or orchestrator modification in 8C.2.

## Interpretation of tests

The sibling `tests/090-linux-transaction-prototype.sh` is an intentionally disposable test fixture. It rejects non-temporary roots and needs an explicit marker. It is **not** a root installer and is not hardened against an adversary who can race/write the disposable test root. Its synthetic tests demonstrate only selected failure-control mechanics, not production transaction guarantees.
