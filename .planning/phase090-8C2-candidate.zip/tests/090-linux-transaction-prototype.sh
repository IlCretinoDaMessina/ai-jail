#!/usr/bin/env bash
# OFFLINE TEST FIXTURE ONLY. Rejects production paths; never invokes privilege escalation.
set -euo pipefail
[[ $# -ge 2 && $# -le 5 ]] || { echo 'USAGE: install|recover ROOT [SOURCE EXPECTED_SHA256 [inject]]' >&2; exit 2; }
op=$1; root=$2; source=${3:-}; expected=${4:-}; inject=${5:-}
[[ $op == install || $op == recover ]] || { echo 'invalid operation' >&2; exit 2; }
[[ -d $root && ! -L $root ]] || { echo 'invalid root' >&2; exit 2; }
root=$(realpath -e -- "$root")
[[ $root == "${TMPDIR:-/tmp}"/phase090-8c2-* || $root == /tmp/phase090-8c2-* ]] || { echo 'not an explicitly disposable root' >&2; exit 2; }
[[ -f $root/.phase090-disposable-test-only && ! -L $root/.phase090-disposable-test-only ]] || { echo 'missing marker' >&2; exit 2; }
[[ $(cat -- "$root/.phase090-disposable-test-only") == PHASE090-OFFLINE-TEST-ONLY ]] || { echo 'bad marker' >&2; exit 2; }
# Ensure every component underneath root is a physical directory before use.
for part in work versions; do
  [[ ! -e $root/$part && ! -L $root/$part ]] || [[ -d $root/$part && ! -L $root/$part ]] || { echo 'unsafe directory' >&2; exit 2; }
done
work=$root/work; versions=$root/versions; journal=$work/journal; stage=$work/payload.stage; target=$versions/payload.bin
if [[ $op == recover ]]; then
  [[ -d $work && ! -L $work && -f $journal && ! -L $journal ]] || { echo 'no safe journal' >&2; exit 2; }
  [[ $(cat -- "$journal") == STAGED:* ]] || { echo 'non-staged journal; manual review' >&2; exit 2; }
  [[ ! -e $target && ! -L $target ]] || { echo 'destination exists; manual review' >&2; exit 2; }
  [[ ! -L $stage ]] || { echo 'stage symlink' >&2; exit 2; }
  rm -f -- "$stage"; rm -- "$journal"; echo 'PASS: explicit staged recovery'; exit 0
fi
[[ $expected =~ ^[a-fA-F0-9]{64}$ && -f $source && ! -L $source && ( -z $inject || $inject == after-journal ) ]] || { echo 'invalid install args' >&2; exit 2; }
[[ -f $source && ! -L $source ]] || { echo 'unsafe source' >&2; exit 2; }
[[ ! -e $journal && ! -L $journal && ! -e $stage && ! -L $stage && ! -e $target && ! -L $target ]] || { echo 'occupied path or unresolved journal' >&2; exit 2; }
actual=$(sha256sum -- "$source"); actual=${actual%% *}
[[ ${actual,,} == ${expected,,} ]] || { echo 'source hash mismatch' >&2; exit 2; }
mkdir -m 700 -- "$work" "$versions" 2>/dev/null || {
  [[ -d $work && ! -L $work && -d $versions && ! -L $versions ]] || { echo 'unsafe directory' >&2; exit 2; }
}
[[ -d $work && ! -L $work && -d $versions && ! -L $versions ]] || { echo 'unsafe directory' >&2; exit 2; }
( umask 077; cp --no-dereference -- "$source" "$stage" )
[[ ! -L $stage ]] || { echo 'unsafe staged file' >&2; exit 2; }
staged=$(sha256sum -- "$stage"); staged=${staged%% *}; [[ $staged == "$actual" ]] || { echo 'stage hash mismatch' >&2; exit 2; }
( umask 077; printf 'STAGED:%s\n' "$actual" > "$journal" )
[[ $inject != after-journal ]] || { echo 'INJECTED_FAILURE_AFTER_JOURNAL' >&2; exit 19; }
mv -n -- "$stage" "$target"
[[ -f $target && ! -L $target ]] || { echo 'promotion failed' >&2; exit 2; }
promoted=$(sha256sum -- "$target"); promoted=${promoted%% *}; [[ $promoted == "$actual" ]] || { echo 'promotion hash mismatch; manual review' >&2; exit 2; }
printf 'COMMITTED:%s\n' "$actual" > "$journal"
echo 'PASS: disposable commit'
