#!/usr/bin/env bash
# Offline synthetic Linux tests; invoke from any directory. No WSL install or network.
set -euo pipefail
script=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/090-linux-transaction-prototype.sh
root=$(mktemp -d "${TMPDIR:-/tmp}/phase090-8c2-XXXXXXXX")
trap 'rm -rf -- "$root"' EXIT
case_dir() { mkdir -- "$root/$1"; printf '%s' PHASE090-OFFLINE-TEST-ONLY > "$root/$1/.phase090-disposable-test-only"; }
printf 'synthetic offline payload' > "$root/source"; hash=$(sha256sum "$root/source"); hash=${hash%% *}
reject() { if bash "$script" "$@" > "$root/out" 2>&1; then echo 'FAIL: unexpectedly accepted' >&2; exit 1; fi; }
case_dir hash; reject install "$root/hash" "$root/source" "$(printf '0%.0s' {1..64})"; [[ ! -e $root/hash/work/journal ]]; echo 'PASS: wrong hash rejected'
mkdir -- "$root/unmarked"; reject install "$root/unmarked" "$root/source" "$hash"; echo 'PASS: marker required'
case_dir symlink; mkdir -- "$root/outside"; ln -s -- "$root/outside" "$root/symlink/work"; reject install "$root/symlink" "$root/source" "$hash"; [[ ! -e $root/outside/journal ]]; echo 'PASS: symlink directory rejected'
case_dir linkedsource; ln -s -- "$root/source" "$root/link"; reject install "$root/linkedsource" "$root/link" "$hash"; echo 'PASS: symlink source rejected'
case_dir interrupt; if bash "$script" install "$root/interrupt" "$root/source" "$hash" after-journal > "$root/out" 2>&1; then echo 'FAIL: injection did not interrupt' >&2; exit 1; else rc=$?; [[ $rc -eq 19 ]]; fi
[[ -f $root/interrupt/work/journal ]]; reject install "$root/interrupt" "$root/source" "$hash"; bash "$script" recover "$root/interrupt" > /dev/null; [[ ! -e $root/interrupt/work/journal ]]; echo 'PASS: interruption is fail-closed and explicitly recoverable'
case_dir commit; bash "$script" install "$root/commit" "$root/source" "$hash" > /dev/null; [[ $(cat "$root/commit/work/journal") == "COMMITTED:$hash" ]]; reject install "$root/commit" "$root/source" "$hash"; reject recover "$root/commit"; echo 'PASS: commit and occupied destination fail-closed'
echo 'PASS: all synthetic Linux transaction checks'
