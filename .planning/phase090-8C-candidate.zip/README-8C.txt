TASK 090-8C — ADDITIVE OFFLINE TRANSACTION PROTOTYPE (NOT INSTALLER)

Contents:
 tests/090-transaction-prototype.ps1
 tests/verify-090-transaction.ps1
 README-8C.txt
 SHA256SUMS.txt

No existing project files are replaced. The tested 8B.1 review-only entry point remains unchanged and --apply remains rejected.
Prototype accepts only a caller-created disposable root with a matching marker; never supply project root, WSL root, or production path. It operates solely on synthetic test payload in OS temp. Its journal state machine is a prototype, NOT suitable for live installer approval. No downloads, WSL, GSD install, launcher, or networking.

MiMo placement and execution must be separately authorised. After copying into D:\.coding\.ai-jail, invoke ONLY:
 powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File .\tests\verify-090-transaction.ps1

Remaining design work: complete GSD lockfile/lifecycle audit; stronger transaction semantics (atomic promotion, durable rollback, strict reparse checks at every boundary, idempotence and crash recovery); managed config precedence/auth; external provider/installation host approval; production launcher; Phase 080 regression.
