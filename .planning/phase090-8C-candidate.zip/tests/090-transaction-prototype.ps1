# Offline disposable transaction prototype. Never points at production paths.
[CmdletBinding()]
param(
 [Parameter(Mandatory=$true)][ValidateSet('Install','Recover')][string]$Operation,
 [Parameter(Mandatory=$true)][string]$SandboxRoot,
 [string]$SourceFile,
 [string]$ExpectedSha256,
 [switch]$InjectFailureAfterJournal
)
$ErrorActionPreference='Stop'
function Assert-Contained([string]$root,[string]$path) {
 $r=[IO.Path]::GetFullPath($root).TrimEnd([IO.Path]::DirectorySeparatorChar)+[IO.Path]::DirectorySeparatorChar
 $p=[IO.Path]::GetFullPath($path)
 if (-not $p.StartsWith($r,[StringComparison]::OrdinalIgnoreCase)) { throw 'Path escapes disposable root' }
}
function Test-NoLinks([string]$path) {
 $item=Get-Item -LiteralPath $path -Force -ErrorAction Stop
 if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Reparse point rejected' }
}
$root=[IO.Path]::GetFullPath($SandboxRoot)
if (-not (Test-Path -LiteralPath $root -PathType Container)) { throw 'Disposable root must already exist' }
Test-NoLinks $root
$marker=Join-Path $root '.phase090-disposable-test-only'
if (-not (Test-Path -LiteralPath $marker -PathType Leaf)) { throw 'Disposable-root marker missing' }
Test-NoLinks $marker
if ((Get-Content -LiteralPath $marker -Raw).Trim() -cne 'PHASE090-OFFLINE-TEST-ONLY') { throw 'Disposable-root marker mismatch' }
if ($root -match '(?i)(^|[\\/])(opt|windows|program files|\.ai-jail)([\\/]|$)') { throw 'Production-looking root rejected' }
$work=Join-Path $root 'transaction'; $target=Join-Path $root 'installed'; $journal=Join-Path $work 'journal.json'; $stage=Join-Path $work 'stage.bin'; $promoted=Join-Path $target 'artifact.bin'
foreach($p in @($work,$target,$journal,$stage,$promoted)) { Assert-Contained $root $p }
foreach($p in @($work,$target)) { if(Test-Path -LiteralPath $p) { Test-NoLinks $p } }
if ($Operation -ceq 'Recover') {
 if (-not (Test-Path -LiteralPath $journal -PathType Leaf)) { throw 'No journal to recover' }
 Test-NoLinks $journal
 $j=Get-Content -LiteralPath $journal -Raw | ConvertFrom-Json -ErrorAction Stop
 if ($j.schema -ne 1 -or $j.state -cne 'STAGED' -or $j.target -cne 'artifact.bin') { throw 'Unexpected journal state; manual review required' }
 if (Test-Path -LiteralPath $promoted) { throw 'Promoted content exists; manual review required' }
 if (Test-Path -LiteralPath $stage) { Test-NoLinks $stage; Remove-Item -LiteralPath $stage -Force }
 Remove-Item -LiteralPath $journal -Force
 Write-Output 'PASS: disposable staged transaction recovered'; exit 0
}
if (Test-Path -LiteralPath $journal) { throw 'Unresolved journal; fail closed' }
if (Test-Path -LiteralPath $promoted) { throw 'Occupied destination; fail closed' }
if (-not $SourceFile -or $ExpectedSha256 -cnotmatch '^[a-fA-F0-9]{64}$') { throw 'Missing source or valid SHA256' }
if (-not (Test-Path -LiteralPath $SourceFile -PathType Leaf)) { throw 'Source must be a file' }
Test-NoLinks $SourceFile
$actual=(Get-FileHash -LiteralPath $SourceFile -Algorithm SHA256).Hash
if ($actual -cne $ExpectedSha256.ToUpperInvariant()) { throw 'Source hash mismatch before staging' }
if (-not (Test-Path -LiteralPath $work)) { $null=New-Item -ItemType Directory -Path $work }
if (-not (Test-Path -LiteralPath $target)) { $null=New-Item -ItemType Directory -Path $target }
Copy-Item -LiteralPath $SourceFile -Destination $stage -ErrorAction Stop
if ((Get-FileHash -LiteralPath $stage -Algorithm SHA256).Hash -cne $actual) { throw 'Stage hash mismatch' }
$j=@{schema=1;state='STAGED';target='artifact.bin';sha256=$actual} | ConvertTo-Json -Compress
[IO.File]::WriteAllText($journal,$j,[Text.UTF8Encoding]::new($false))
if ($InjectFailureAfterJournal) { throw 'INJECTED_FAILURE_AFTER_JOURNAL' }
Move-Item -LiteralPath $stage -Destination $promoted -ErrorAction Stop
if ((Get-FileHash -LiteralPath $promoted -Algorithm SHA256).Hash -cne $actual) { throw 'Promotion hash mismatch; manual review required' }
# Journal deliberately persists in committed state for observable test audit.
[IO.File]::WriteAllText($journal,(@{schema=1;state='COMMITTED';target='artifact.bin';sha256=$actual}|ConvertTo-Json -Compress),[Text.UTF8Encoding]::new($false))
Write-Output 'PASS: disposable transaction committed'; exit 0
