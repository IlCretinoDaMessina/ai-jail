# Offline-only disposable failure tests; creates all files under OS temp.
$ErrorActionPreference='Stop'
$script=Join-Path $PSScriptRoot '090-transaction-prototype.ps1'
$root=Join-Path ([IO.Path]::GetTempPath()) ('phase090-test-'+[guid]::NewGuid().ToString('N'))
function New-Case([string]$name) {
 $p=Join-Path $root $name; $null=New-Item -ItemType Directory -Path $p -Force
 [IO.File]::WriteAllText((Join-Path $p '.phase090-disposable-test-only'),'PHASE090-OFFLINE-TEST-ONLY',[Text.UTF8Encoding]::new($false)); return $p
}
function Invoke-Case([string]$name,[scriptblock]$body) { & $body; Write-Output "PASS: $name" }
try {
 $null=New-Item -ItemType Directory -Path $root
 $source=Join-Path $root 'source.bin'; [IO.File]::WriteAllText($source,'phase090-test-payload',[Text.UTF8Encoding]::new($false))
 $hash=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
 Invoke-Case 'wrong hash rejected' {
  $p=New-Case 'wronghash'; try { & $script -Operation Install -SandboxRoot $p -SourceFile $source -ExpectedSha256 ('0'*64) *> $null; throw 'Incorrectly accepted wrong hash' } catch { if ($_.Exception.Message -eq 'Incorrectly accepted wrong hash') { throw } }
  if (Test-Path (Join-Path $p 'transaction/journal.json')) { throw 'Wrong-hash journal created' }
 }
 Invoke-Case 'missing marker rejected' {
  $p=Join-Path $root 'nomarker'; $null=New-Item -ItemType Directory -Path $p
  try { & $script -Operation Install -SandboxRoot $p -SourceFile $source -ExpectedSha256 $hash *> $null; throw 'Incorrectly accepted missing marker' } catch { if ($_.Exception.Message -eq 'Incorrectly accepted missing marker') { throw } }
 }
 Invoke-Case 'injected interruption and explicit recovery' {
  $p=New-Case 'interruption'; try { & $script -Operation Install -SandboxRoot $p -SourceFile $source -ExpectedSha256 $hash -InjectFailureAfterJournal *> $null; throw 'Injection failed to stop' } catch { if ($_.Exception.Message -ne 'INJECTED_FAILURE_AFTER_JOURNAL') { throw } }
  if (-not (Test-Path (Join-Path $p 'transaction/journal.json'))) { throw 'Missing failure journal' }
  try { & $script -Operation Install -SandboxRoot $p -SourceFile $source -ExpectedSha256 $hash *> $null; throw 'Unresolved journal incorrectly accepted' } catch { if ($_.Exception.Message -eq 'Unresolved journal incorrectly accepted') { throw } }
  & $script -Operation Recover -SandboxRoot $p | Out-Null
  if (Test-Path (Join-Path $p 'transaction/journal.json')) { throw 'Recovery journal remains' }
 }
 Invoke-Case 'valid commit and occupied destination rejection' {
  $p=New-Case 'commit'; & $script -Operation Install -SandboxRoot $p -SourceFile $source -ExpectedSha256 $hash | Out-Null
  if ((Get-FileHash (Join-Path $p 'installed/artifact.bin') -Algorithm SHA256).Hash -cne $hash) { throw 'Wrong committed bytes' }
  try { & $script -Operation Install -SandboxRoot $p -SourceFile $source -ExpectedSha256 $hash *> $null; throw 'Incorrectly accepted second installation' } catch { if ($_.Exception.Message -eq 'Incorrectly accepted second installation') { throw } }
 }
 Write-Output 'PASS: all disposable transaction tests'; exit 0
} catch { [Console]::Error.WriteLine("FAIL: $($_.Exception.Message)"); exit 1 }
finally { if (Test-Path -LiteralPath $root) { Remove-Item -LiteralPath $root -Recurse -Force } }
