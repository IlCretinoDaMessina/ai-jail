# Phase 090 / 8C.3 — GSD Core dependency provenance (review-only)

Status: INCOMPLETE / FAIL CLOSED. This document is not installation or download authorisation.

## Fixed identity and independently observed upstream metadata

- Intended maintained repository: https://github.com/open-gsd/gsd-core
- Intended Git tag: v1.15.0; proposed commit in existing Phase 090 manifest: b10ab3fdeb6274b373859ccd6e99b7e1cf17388e (not independently checked by this document).
- Package: `@opengsd/gsd-core@1.15.0`. Existing manifest's npm integrity is PROPOSED, not yet verified against acquired tarball.
- Version-tag source inspected: https://raw.githubusercontent.com/open-gsd/gsd-core/v1.15.0/package.json
- Engines: Node >=24.0.0, npm >=10.0.0. Pin exact Node/npm runtime and record their provenance/hashes before installation.
- Production dependency declarations: `@anthropic-ai/claude-agent-sdk: ^0.2.84`, `ws: ^8.21.0`; optional `fallow: ^2.70.0`. These are ranges, not reproducible dependency versions.
- The source manifest defines `prepare` and `prepack` (`npm run build:lib`) and `prepublishOnly`; package execution/install hooks (including transitive dependencies) require inspection before execution. Never assume `--ignore-scripts` alone ensures the assembled OpenCode integration works.
- Source package-lock from `next` or a changing branch is NOT a valid lock for v1.15.0. Do not automatically adopt any upstream lock without checking root identity, version, and resolved graph.

## Required acquisition and reproducibility gate (separate user approval)

1. Approve a bounded read-only **host-side** acquisition operation, explicitly separate from production WSL installation. Enumerate observed DNS names and redirects; do not broaden runtime provider hosts. Do not execute fetched packages.
2. Obtain npm registry metadata for precisely `@opengsd/gsd-core@1.15.0`; record registry response provenance, resolved `dist.tarball`, `dist.integrity`, and optional signatures/attestations. Compare the integrity to the existing proposed value; fail closed on discrepancy.
3. Acquire bytes only after approval; verify npm integrity of original `.tgz` and preserve SHA-256, size, source URL, retrieval date. Cross-check tarball `package/package.json` name/version/engines/dependencies/optionalDependencies/scripts against immutable tag contents, recording differences.
4. Generate an isolated candidate production dependency resolution with exact Node/npm versions and a frozen environment/platform (`linux`, x64, glibc); **no scripts executed** during resolution. Record npm version, registry configuration, installation-host redirects, full `package-lock.json` v3, and hash. Do not claim reproducibility from root package version alone.
5. Review every resolved node for pinned version, supported registry URL, SRI integrity, parent relationships, platform/CPU/OS flags, optional/peer graph, any package with lifecycle scripts, and executable/native payloads. Record advisory findings separately; do not silently discard optional dependencies. Reject git, http, file, workspace and unapproved alternate registries.
6. Review packed package file list and relevant OpenCode installer outputs without running unreviewed `bin/install.js`; inspect generated paths, hooks, plugins, commands, symlinks, unexpected permissions and required write locations. Define deterministic managed-tree manifest and content hashes.
7. Confirm GSD can work with the pinned OpenCode v1.18.34 and selected Node/npm runtime, inside approved private home. Project `.planning/` is retained; no auto-migration.
8. Only after independent review may approvals be proposed for actual install, separate from runtime policy/production wrapper/Phase 080. Existing `complete_reviewed_lockfile_present`, `generated_tree_audited`, `verified_for_installation` and `live_apply_authorized` remain FALSE.

## Evidence record to fill after authorised acquisition

| Evidence | Value / status |
|---|---|
| tag commit verification | PENDING |
| registry metadata snapshot and retrieval timestamp | PENDING |
| tarball URL, size, SHA-256 and independently checked SRI | PENDING |
| exact Node/npm binary provenance, platform | PENDING |
| frozen package-lock SHA-256 and full graph audit | PENDING |
| scripts/native/optional dependency audit | PENDING |
| emitted OpenCode tree and permissions audit | PENDING |
| install host/redirect review | PENDING |
| independent security review and user approval | PENDING |

This document deliberately does not embed guessed checksums, a synthetic lockfile labelled production, or a live installation command.
