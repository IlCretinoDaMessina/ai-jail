# Offline read-only gate test. Does not fetch or execute any dependency.
$ErrorActionPreference = 'Stop'
try {
  $root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
  $manifest = Get-Content -LiteralPath (Join-Path $root '090-tool-manifest.json') -Raw | ConvertFrom-Json
  $gate = Get-Content -LiteralPath (Join-Path $root 'assets/090/gsd-acquisition-gate.json') -Raw | ConvertFrom-Json
  if ($gate.schema -ne 1 -or $gate.status -ne 'BLOCKED_REVIEW_ONLY') { throw 'Invalid gate schema/status' }
  if ($manifest.gsd.package -ne $gate.package -or $manifest.gsd.version -ne $gate.version) { throw 'GSD identity drift' }
  if ($gate.engines_from_tag.node -ne '>=24.0.0' -or $gate.engines_from_tag.npm -ne '>=10.0.0') { throw 'Toolchain prerequisite drift' }
  if ($gate.runtime_dependency_ranges_from_tag.'@anthropic-ai/claude-agent-sdk' -ne '^0.2.84' -or $gate.runtime_dependency_ranges_from_tag.ws -ne '^8.21.0' -or $gate.optional_dependency_ranges_from_tag.fallow -ne '^2.70.0') { throw 'Tag dependency declaration drift' }
  $blocked = @('registry_metadata_verified','tarball_acquired_and_verified','tag_commit_verified','node_npm_toolchain_pinned','frozen_lockfile_present','full_transitive_graph_audited','emitted_tree_audited','network_redirects_approved','downloads_authorized','installation_authorized','live_apply_authorized')
  foreach ($field in $blocked) { if ($gate.$field -ne $false) { throw "Unsafe gate enabled: $field" } }
  if ($gate.requires_script_review -ne $true) { throw 'Script review unexpectedly waived' }
  if ($manifest.live_apply_authorized -ne $false -or $manifest.gsd.verified_for_installation -ne $false -or $manifest.gsd.complete_reviewed_lockfile_present -ne $false -or $manifest.approvals.live_apply -ne $false) { throw 'Production manifest unexpectedly authorizes installation' }
  Write-Output 'PASS: GSD identity, prerequisites, dependency declarations and fail-closed acquisition gates'
  exit 0
} catch {
  Write-Error $_
  exit 1
}
