Phase 090 Task 8C.3 — additive, offline-only provenance specification.
Three payload files. Nothing in this archive installs packages, downloads artifacts, changes production policy, or approves live apply.
Review the provenance document; placement and Windows test must be separately authorised.
