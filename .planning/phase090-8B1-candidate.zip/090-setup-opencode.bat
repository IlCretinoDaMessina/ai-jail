@echo off
setlocal DisableDelayedExpansion
REM Phase 090 candidate review-only; no installation path.
if /I not "%~1"=="--review" goto :usage
if not "%~2"=="" goto :usage
powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0090-setup-opencode.ps1" -Review
set "RC=%ERRORLEVEL%"
if "%RC%"=="0" exit /b 0
exit /b 1
:usage
>&2 echo Phase 090 candidate accepts exactly --review. Apply is disabled.
exit /b 1
