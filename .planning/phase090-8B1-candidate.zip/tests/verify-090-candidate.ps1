# Offline candidate-specific tests. Do not invoke a real installation or orchestration.
$ErrorActionPreference = 'Stop'
try {
    $root = Split-Path -Parent $PSScriptRoot
    $m = Get-Content -LiteralPath (Join-Path $root '090-tool-manifest.json') -Raw | ConvertFrom-Json -ErrorAction Stop
    if ($m.schema -ne 2 -or $m.status -cne 'CANDIDATE_REVIEW_ONLY' -or $m.live_apply_authorized -cne $false -or $m.approvals.live_apply -cne $false) { throw 'Fail-closed gates mismatch' }
    if ($m.opencode.archive_sha256 -cne '24b0d458d21ef548b2752166303defcf7f4945b049fb4876ab78dfaf86d81b27') { throw 'OpenCode archive hash mismatch' }
    if ($m.opencode.binary_sha256 -cne '9ca0b9953d49997601655e54f846a3efa464f237e47c6f1b04716d0f2e64c4c2') { throw 'OpenCode binary hash mismatch' }
    if ($m.gsd.complete_reviewed_lockfile_present -cne $false -or $m.gsd.verified_for_installation -cne $false) { throw 'GSD is incorrectly marked ready' }
    if ($m.runtime.provider_hosts_approved_for_production -cne $false -or $m.runtime.production_loopback_exception_approved -cne $false -or $m.installation.downloads_authorized_for_production -cne $false) { throw 'Unapproved production gate' }
    $managed = Get-Content -LiteralPath (Join-Path $root 'assets/090/opencode-managed.json') -Raw | ConvertFrom-Json -ErrorAction Stop
    if ($managed.autoupdate -cne $false -or $managed.share -cne 'disabled') { throw 'Update/share config incorrect' }
    $bat = Get-Content -LiteralPath (Join-Path $root '090-setup-opencode.bat') -Raw
    $ps = Get-Content -LiteralPath (Join-Path $root '090-setup-opencode.ps1') -Raw
    if ($bat -notmatch 'if /I not "%~1"=="--review"' -or $bat -notmatch 'if not "%~2"==""') { throw 'BAT entry restriction changed' }
    if ($ps -notmatch 'CANDIDATE_REVIEW_ONLY') { throw 'Review guard missing' }
    if ($ps -match '(?im)^\s*(Invoke-WebRequest|Invoke-RestMethod|Start-Process|Remove-Item|Copy-Item|Move-Item|Set-Content)\b' -or $ps -match '(?im)^\s*(?:&\s*)?wsl(?:\.exe)?\s') { throw 'Unexpected operation in review-only PowerShell script' }
    $tokens = $null; $errors = $null
    $null = [System.Management.Automation.Language.Parser]::ParseFile((Join-Path $root '090-setup-opencode.ps1'), [ref]$tokens, [ref]$errors)
    if ($errors.Count -ne 0) { throw ('PowerShell parse error: ' + ($errors | Out-String)) }
    Write-Output 'PASS: candidate manifest/config review guards, pins, offline operation scan, PS parser'
    exit 0
} catch {
    [Console]::Error.WriteLine("FAIL: $($_.Exception.Message)")
    exit 1
}
