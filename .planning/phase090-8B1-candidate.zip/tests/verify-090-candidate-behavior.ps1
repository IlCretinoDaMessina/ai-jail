# Run only after candidate files are installed in the project root; does not run setup apply.
$ErrorActionPreference = 'Stop'
try {
    $root = Split-Path -Parent $PSScriptRoot
    $baseline = @('000-run-all.bat','_common.bat','080-setup-sandboxes.bat','080-setup-sandboxes.ps1','config.env','080-review-gates.md','.planning/phase-080-validation-report.md')
    $before = @{}
    foreach ($f in $baseline) { $before[$f] = (Get-FileHash -LiteralPath (Join-Path $root $f) -Algorithm SHA256).Hash }
    $script = Join-Path $root '090-setup-opencode.bat'
    foreach ($case in @(
        @{Name='review';Arg='--review';Code=0;Text='CANDIDATE: REVIEW ONLY'},
        @{Name='apply rejected';Arg='--apply';Code=1;Text='Apply is disabled'},
        @{Name='empty rejected';Arg='';Code=1;Text='accepts exactly'},
        @{Name='extra rejected';Arg='--review --apply';Code=1;Text='accepts exactly'},
        @{Name='unknown rejected';Arg='--unknown';Code=1;Text='accepts exactly'}
    )) {
        $cmd = 'call "' + $script + '" ' + $case.Arg + ' 2>&1'
        $out = & cmd.exe /d /c $cmd | Out-String
        $rc = $LASTEXITCODE
        if ($rc -ne $case.Code -or $out -notmatch [regex]::Escape($case.Text)) { throw "Case failed: $($case.Name) (exit $rc)" }
        Write-Output "PASS: $($case.Name)"
    }
    foreach ($f in $baseline) { if ((Get-FileHash -LiteralPath (Join-Path $root $f) -Algorithm SHA256).Hash -cne $before[$f]) { throw "Baseline changed: $f" } }
    Write-Output 'PASS: accepted baseline unchanged'
    exit 0
} catch {
    [Console]::Error.WriteLine("FAIL: $($_.Exception.Message)")
    exit 1
}
