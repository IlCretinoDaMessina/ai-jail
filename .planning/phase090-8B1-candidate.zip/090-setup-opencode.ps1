# Candidate review-only implementation. No apply/download/WSL path.
[CmdletBinding()]
param([Parameter(Mandatory=$true)][switch]$Review)
$ErrorActionPreference = 'Stop'
try {
    if (-not $Review) { throw 'Review only.' }
    $manifestPath = Join-Path $PSScriptRoot '090-tool-manifest.json'
    $configPath = Join-Path $PSScriptRoot 'config.env'
    $gatesPath = Join-Path $PSScriptRoot '090-review-gates.md'
    foreach ($file in @($manifestPath, $configPath, $gatesPath)) {
        if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { throw "Missing required input: $(Split-Path -Leaf $file)" }
    }
    $m = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json -ErrorAction Stop
    if ($m.schema -ne 2 -or $m.status -cne 'CANDIDATE_REVIEW_ONLY' -or $m.live_apply_authorized -cne $false -or $m.approvals.live_apply -cne $false) {
        throw 'Manifest approval/schema mismatch; fail closed.'
    }
    if ($m.opencode.version -cne '1.18.34' -or $m.gsd.package -cne '@opengsd/gsd-core' -or $m.gsd.version -cne '1.15.0') { throw 'Unexpected tool pins.' }
    if ($m.runtime.provider_hosts_approved_for_production -cne $false -or $m.installation.downloads_authorized_for_production -cne $false) { throw 'Unapproved candidate state.' }
    $expectedKeys = @('INSTALL_OPENCODE','INSTALL_VSCODE','ENABLE_NONO','ALLOW_HOSTS_INSTALL')
    $seen = @{}
    foreach ($line in (Get-Content -LiteralPath $configPath -ErrorAction Stop)) {
        if ($line -match '^\s*(?:#|$)') { continue }
        if ($line -match '^\s*([A-Z][A-Z0-9_]*)\s*=(.*)$') {
            $key = $Matches[1]; $value = $Matches[2].Trim()
            if ($expectedKeys -ccontains $key) {
                if ($seen.ContainsKey($key)) { throw "Duplicate expected config key: $key" }
                $seen[$key] = $value
            }
        } elseif ($line -match '^\s*(INSTALL_OPENCODE|INSTALL_VSCODE|ENABLE_NONO|ALLOW_HOSTS_INSTALL)') {
            throw 'Malformed expected config key.'
        }
    }
    foreach ($key in $expectedKeys) { if (-not $seen.ContainsKey($key)) { throw "Missing config key: $key" } }
    if ($seen['INSTALL_OPENCODE'] -cne '1' -or $seen['INSTALL_VSCODE'] -cne '0' -or $seen['ENABLE_NONO'] -cne '0') { throw 'Install flags differ from reviewed scope.' }
    Write-Output 'PHASE 090 CANDIDATE: REVIEW ONLY; APPLY DISABLED'
    Write-Output "OpenCode version: $($m.opencode.version); archive SHA256: $($m.opencode.archive_sha256)"
    Write-Output "GSD: $($m.gsd.package)@$($m.gsd.version); transitive lockfile: NOT VERIFIED"
    Write-Output "Proposed runtime provider hosts: $($m.runtime.provider_hosts_proposed -join ',') (NOT APPROVED FOR PRODUCTION)"
    Write-Output "Current shared installation hosts (informational only): $($seen['ALLOW_HOSTS_INSTALL'])"
    Write-Output 'BLOCKED: production provenance, complete GSD lockfile, redirects, policy precedence, loopback exception approval, runtime auth/persistence, integration changes, live apply.'
    Write-Output 'No download, WSL invocation, setup phase, provider call or production write was performed by review mode.'
    exit 0
} catch {
    [Console]::Error.WriteLine("Phase 090 candidate review failed: $($_.Exception.Message)")
    exit 1
}
