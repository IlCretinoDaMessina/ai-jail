AI Jail Phase 090 — Stage 8B.1 candidate package (OFFLINE / REVIEW ONLY)

Do NOT extract directly over an existing project. Inspect and back up the four same-name scaffold files first. Candidate replaces only: 090-tool-manifest.json, 090-review-gates.md, 090-setup-opencode.bat, 090-setup-opencode.ps1.
Adds: assets/090/opencode-managed.json, assets/090/README.md, tests/verify-090-candidate.ps1, tests/verify-090-candidate-behavior.ps1.
Does NOT contain installer/apply logic, production launchers or GSD lockfile. Existing tests targeting schema 1 scaffold intentionally remain historical and will not pass against schema 2; use candidate-specific tests instead.
Prerequisites: existing project config.env, unchanged accepted Phase 080 artifacts.
Offline test commands (after separately approved placement):
 powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File .\tests\verify-090-candidate.ps1
 powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File .\tests\verify-090-candidate-behavior.ps1
Do not run real orchestrator or any --apply.
