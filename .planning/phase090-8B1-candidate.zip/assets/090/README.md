# Candidate managed config (NOT DEPLOYABLE)

`opencode-managed.json` is a proposed configuration specimen, not a verified security policy. Effective config precedence (managed vs project `opencode.json`, `.opencode`, and plugin loading), auth, server binding and persistence still require pinned-version acceptance. Do not copy into production or use as proof of enforcement. Exact final schema and support for managed policy must be confirmed before promotion. GSD-generated configuration is intentionally absent until lockfile and installer transformations are audited.
