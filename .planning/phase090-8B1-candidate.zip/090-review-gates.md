# Phase 090 — candidate review gates (8B.1)

Status: CANDIDATE / REVIEW ONLY. This record is not production approval.

## Verified experimental evidence (not production acceptance)
- OpenCode v1.18.34 baseline archive and extracted binary matched the recorded SHA-256 and sizes.
- Experimental launcher hash: `b8535ac09cde745e66654babf06eb76f17e8c03016b3a6915c57bc48cee17643`.
- Direct authenticated sandbox-local loopback request returned 200; OpenCode TUI rendered with *temporary process-local* NO_PROXY/no_proxy for `127.0.0.1,localhost`.
- One `opencode/big-pickle` request returned `OK`, exit 0, via experimental `opencode.ai`-only launcher.
- LB-05 and LB-06A negative checks supported namespace/external-network/WSL isolation. Complete production regression still required.

## Agreed scope
- OpenCode free-model provider initially. `opencode.ai` is a *proposed production* allow-host, not automatically approved for apply.
- Maintained `open-gsd/gsd-core`; archived original and standalone Pi not installed.
- Preserve `.planning/`, `INSTALL_VSCODE=0`, `ENABLE_NONO=0`, accepted Phase 080 baseline.
- No production installation, launcher replacement, provider call or live apply in batch 8B.1.

## BLOCKING gates before implementation/apply
- [ ] A1: upstream artifact provenance and production CPU/OS prerequisites approved (experimental archive hash recorded).
- [ ] A2: full integrity-bearing GSD lockfile, lifecycle audit, installer-transform and generated-tree audit.
- [ ] A3: precise phase-only installation hosts and real redirect evidence.
- [ ] A4/A5: free provider/model and `opencode.ai`-only production runtime policy accepted; remove installation hosts.
- [ ] A6: root-owned versioned paths and managed policy precedence tested against project config/plugins.
- [ ] A7: secured Windows launcher replacement separately reviewed; no Windows OpenCode fallback.
- [ ] A8: production wrapper/config changes separately approved; preserve Phase 080 unless explicitly superseded.
- [ ] A9: mocked orchestrator forwarding and exit-code contract proven before edits to `000-run-all.bat`.
- [ ] A10: persistence scope chosen; no secret persistence under writable project.
- [x] A11: no VS Code integration, `INSTALL_VSCODE=0`.
- [ ] A12: distinct approval for download/install, live provider requests, any WSL termination, and apply.
- [ ] Production loopback exception threat analysis explicitly accepted; scope must be after namespace entry only.
- [ ] Authenticated loopback-only server design and lifecycle/cleanup approved.
- [ ] Final production Phase 080 + Phase 090 regression and negative tests pass.

## Candidate review instructions
`090-setup-opencode.bat --review` is offline and read-only; `--apply` is intentionally rejected with exit 1. Never execute real `000-run-all.bat` for this candidate. Old scaffold tests must not be taken as proof for revised candidate files.
